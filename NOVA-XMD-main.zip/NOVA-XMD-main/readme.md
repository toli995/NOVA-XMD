<p align="center">
  <h1 align="center" style="font-family: 'Orbitron', sans-serif; text-shadow: 0 0 10px #00ffff, 0 0 20px #0088ff;">𝗡𝗢𝗩𝗔-𝗫𝗠𝗗</h1>
</p>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Orbitron&weight=600&size=25&duration=4000&pause=1000&color=00F7FF&center=true&vCenter=true&width=500&lines=ULTIMATE+WHATSAPP+BOT;MULTI-DEVICE+SUPPORT;POWERED+BY+BAILEYS;FAST++SECURE++RELIABLE" alt="Animated Typing SVG" />
</p>

<div align="center">
  <a href="https://github.com/novaxmd/followers"><img title="Followers" src="https://img.shields.io/github/followers/novaxmd?color=EB5406&style=for-the-badge&logo=github&logoColor=white"></a>
  <a href="https://github.com/novaxmd/NOVA-XMD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/novaxmd/NOVA-XMD?color=FFCE44&style=for-the-badge&logo=reverbnation&logoColor=white"></a>
  <a href="https://github.com/novaxmd/NOVA-XMD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/novaxmd/NOVA-XMD?color=FF007F&style=for-the-badge&logo=git&logoColor=white"></a>
  <a href="https://github.com/novaxmd/NOVA-XMD/"><img title="Size" src="https://img.shields.io/github/repo-size/novaxmd/NOVA-XMD?style=for-the-badge&color=FFFF33&logo=docusign&logoColor=white"></a>
  <a href="https://github.com/novaxmd/NOVA-XMD/graphs/commit-activity"><img height="28" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=for-the-badge&logo=gitpod&logoColor=white"></a>
</

---

<p align="center">
  <img src="https://github.com/novaxmd/BMB-XMD-DATA/raw/refs/heads/main/image/picha.jpg" width="270" style="border-radius: 20px;" />
</p>

---

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=8A2BE2&center=true&width=1000&height=200&lines=CLICK-HERE-DEPLOY-NOW" alt="Typing SVG" /></a>
  </div>

  ---
  
<a href="https://media-website-bmb.vercel.app/">
  <img 
    title="DEPLOY-NOW" 
    src="https://img.shields.io/badge/DEPLOY--NOW-Click%20to%20deploy-brightgreen?style=for-the-badge&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAABvUlEQVR4Ae2XjWrCQBBF3wQjqzPIpAZOAjtAezM9nLJKnAFHgqfAXsA2GAgFCGGO7c+ZShDk9Qkq2aXxvPYhfl72EkCAJAvKUlT6f3XivCrCyBlFPLMCRAwAIgz4Fy+LC7v0wm7a7kSaQ7vt2cAzPfDKOEjA4x2g7qdoAzYxrkBqCQDxiLbcRz/3uwD8KXJEG8sbBmkQX2gyZyeDLMPQpvlbVwDp6A9/jRLc1CtkbtYBau2bfbHDy6F4C3GYrYAj7AoP3T5wG2MXCwP+YDBb0RwB8wo6TiZtnTu9GoOuYA0v0RAPvo0MTmKHcTS6cXfW2dCfpURhODafUTrAFlXVmETuSU3rjW8rCu0jGQdXEd1f+rf8COJo3dn96G4Cn0Z7jAH4k40Re2zcnksq2qZT64slAH9ki4RQl/HrpJDJ5DQAO1SCBh5hldMAAAAASUVORK5CYII=&logoColor=white"
    width="300" 
    height="40.45"
    alt="Deploy with Robot"
  />
</a>

---


<h3 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=20&duration=3000&color=FFFFFF&background=000000&center=true&vCenter=true&width=600&lines=💎+NOVA+XMD+Edition+by+Novaxmd🪀;⚡+The+Best+Simple+WhatsApp+Bot+Allover+The+Glob" alt="Footer Animation">
</h3>

---
